#!/bin/bash
echo "Démarrage de l'application web sur le port 8080..."
python main.py web8080