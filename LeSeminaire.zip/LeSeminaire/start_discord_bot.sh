#!/bin/bash
# Script pour démarrer le bot Discord de LeSéminaire

echo "Démarrage du bot Discord LeSéminaire via bot_launcher.py..."
python bot_launcher.py